<template>
    <footer>
        <p>Copyright &copy; 2021 FgTik reserved.</p>
        <p>Developed by Yitian Hu, Yan Pang, Cong Zhang, Tao Jiang, Qinyi Gong, Zihan Zhang</p>
    </footer>
</template>

<script>
export default {
    name: 'Footer',
}
</script>

<style scoped>
    a {
        color: #333;
    }

    footer {
        margin-top: 30px;
        text-align: center;
    }
</style>
