#Frontend setup:

## Project setup
```
npm install
```

## Backend json demo: db.json
### run backend:
```
npm run backend
```
### run serve:
```
npm run serve
```


### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
